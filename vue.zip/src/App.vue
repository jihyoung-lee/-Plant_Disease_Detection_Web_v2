<template>
  <div class="flex min-h-screen w-full bg-white overflow-hidden">
    <!-- 왼쪽 배경 -->
    <div class="w-[200px] h-screen flex-shrink-0">
      <img :src="bg1" class="w-full h-full object-cover opacity-20 pointer-events-none" />
    </div>

    <!-- 가운데 콘텐츠 -->
    <div class="flex-1 flex flex-col relative z-10 bg-white">
      <NavBar />
      <main class="flex-1 px-4 py-8 max-w-5xl mx-auto w-full">
        <router-view />
      </main>
      <Footer />
    </div>

    <!-- 오른쪽 배경 -->
    <div class="w-[200px] h-screen flex-shrink-0">
      <img :src="bg2" class="w-full h-full object-cover opacity-20 pointer-events-none" />
    </div>
  </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'
import Footer from '@/components/Footer.vue'
import bg1 from '@/assets/bg.png'
import bg2 from '@/assets/hero-bg.png'

export default {
  components: {
    NavBar,
    Footer,
  },
  data() {
    return {
      bg1,
      bg2,
    }
  },
}
</script>
