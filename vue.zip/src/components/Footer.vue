<template>
  <footer class="w-full text-center py-6 text-sm text-gray-400">
    © 2025 농업 AI 플랫폼
  </footer>
</template>